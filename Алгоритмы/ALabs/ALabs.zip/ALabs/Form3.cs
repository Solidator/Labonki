﻿using System;
using System.Windows.Forms;

namespace ALabs
{
    public partial class Form3 : Form
    {
        public Form3() //Точка вxода в программу
        {
            InitializeComponent();
        }
        
        private void inclusionSortButton_Click_1(object sender, EventArgs e)//Сортировка прямого включения
        {
            textBox2.Text = Algorithms.IntArrayToString(Algorithms.inclusionSort(Algorithms.StringToIntArray(textBox1.Text)));
        }

        private void selectionSortButton_Click_1(object sender, EventArgs e)//Сортировка прямого выбора
        {
            textBox2.Text = Algorithms.IntArrayToString(Algorithms.selectionSort(Algorithms.StringToIntArray(textBox1.Text)));
        }
    }
}

﻿using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;


namespace ALabs
{
    static class Algorithms
    {
        public static int searchImage(string linetext, string imagetext, bool Registr)//Алгоритм поиска образа в строке
        {
            if (imagetext.Length > linetext.Length || string.IsNullOrWhiteSpace(imagetext) || string.IsNullOrWhiteSpace(linetext))//Проверка входных данных на корректность
                return -1;
            else
            {
                char[] image = new char[1]; char[] line = new char[1];
                int[] d = new int[1103];
                //Записываем в image образ, в line - строку
                Array.Resize(ref image, imagetext.Length);
                Array.Resize(ref line, linetext.Length);
                if (Registr)
                {
                    image = imagetext.ToCharArray();
                    line = linetext.ToCharArray();
                }
                else
                {
                    image = imagetext.ToLower().ToCharArray();
                    line = linetext.ToLower().ToCharArray();
                }
                //Заполняем таблицу длинной образа
                for (int i = 0; i < d.Length; i++)
                    d[i] = image.Length;
                //Проходим образ справа налево и записываем в таблицу удаленность символов от конца строки.
                for (int i = image.Length - 1; i > -1; i--)
                    if (d[image[i]] == image.Length)//Проверяем, не изменено ли значение
                        d[image[i]] = image.Length - i - 1;
                //Алгоритм поиска. m - индекс массива строки, j - образа
                int m = image.Length - 1;
                int lace = 0;
                do
                {
                    for (int j = image.Length - 1; j > -1; j--)//Проходим образ справа налево
                        if (line[m] != image[j])//Если символы не совпали, сдвигаем m на код символа line[m]
                        {
                            m += d[line[m]];
                            break;
                        }
                        else
                            if (j != 0)//Если совпали, проверяем предыдущие символы
                        {
                            m--;
                        }
                        else //Если образ закончился, запоминаем текущий символ и прекращаем поиск
                        {
                            lace = m + 1;
                            m = line.Length;
                        }
                } while (m < line.Length);
                return lace;
            }
        }

        public static int[] inclusionSort(int[] mas)//Сортировка прямого включения
        {
            for (int i = 1; i < mas.Length; i++)
            {
                int value = mas[i]; // запоминаем значение текущего элемента
                int index = i;     // и его индекс
                while ((index > 0) && (mas[index - 1] > value))
                {   // смещаем другие элементы к концу массива пока они меньше index
                    mas[index] = mas[index - 1];
                    index--;    // смещаем индекс к началу массива
                }
                mas[index] = value; // рассматриваемый элемент помещаем на освободившееся место
            }
            return mas;
        }

        public static int[] selectionSort(int[] mas)//Сортировка прямого выбора
        {
            int min, temp; // для поиска минимального элемента и для обмена
            for (int i = 0; i < mas.Length - 1; i++)
            {
                min = i; // запоминаем индекс текущего элемента
                         // ищем минимальный элемент чтобы поместить на место i-ого
                for (int j = i + 1; j < mas.Length; j++)  // для остальных элементов после i-ого
                {
                    if (mas[j] < mas[min]) // если элемент меньше минимального,
                        min = j;       // запоминаем его индекс в min
                }
                temp = mas[i];      // меняем местами i-ый и минимальный элементы
                mas[i] = mas[min];
                mas[min] = temp;
            }
            return mas;
        }

        public static int[] StringToIntArray(string value)//Преобразование строки в целочисленный массив 
        {
            string text = string.Empty;
            text = Regex.Replace(value.Trim(' '), @"\s+", " ");
            List<int> list = new List<int>();
            foreach (string i in text.Split(' '))
                if (int.TryParse(i, out int Number)) list.Add(Number);
            return list.ToArray();
        }

        public static string IntArrayToString(int[] value)//Перевод целочисленного массива в строку
        {
            string text = string.Empty;
            for (int index = 0; index < value.Length; index++)
                text += value[index] + " ";
            return text;
        }

    }
}



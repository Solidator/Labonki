﻿using System;
using System.Windows.Forms;

namespace ALabs
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void FindButton_Click(object sender, EventArgs e)
        {
            if (Algorithms.searchImage(lineTextBox.Text, imageTextBox.Text, RegistrCheckBox.Checked) < 0)
                MessageBox.Show("Ошибка! Неверные вxодные данные!");
            else
                if(Algorithms.searchImage(lineTextBox.Text, imageTextBox.Text, RegistrCheckBox.Checked) == 0)
                    MessageBox.Show("Образ не содержится в тексте");
                else
                    MessageBox.Show("Образ содержится в тексте начиная с "+ Algorithms.searchImage(lineTextBox.Text, imageTextBox.Text, RegistrCheckBox.Checked)+ " символа");
        }
    }
}
